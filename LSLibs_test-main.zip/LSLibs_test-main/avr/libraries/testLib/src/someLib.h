#ifndef SOMELIB_H
  #define SOMELIB_H

  void flashLed(uint8_t led);
  void setLed(uint8_t led);

#endif
